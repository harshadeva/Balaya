<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HouseCondition extends Model
{
    protected $table = 'house_condition';
    protected $primaryKey = 'idhouse_condition';
}

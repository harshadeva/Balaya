<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VotingCondition extends Model
{
    protected $table = 'voting_condition';
    protected $primaryKey = 'idvoting_condition';
}

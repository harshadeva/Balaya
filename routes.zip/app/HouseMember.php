<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HouseMember extends Model
{
    protected $table = 'house_member';
    protected $primaryKey = 'idhouse_member';
}

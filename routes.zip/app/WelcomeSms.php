<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WelcomeSms extends Model
{
    protected $table = 'welcome_sms';
    protected $primaryKey = 'idwelcome_sms';
}

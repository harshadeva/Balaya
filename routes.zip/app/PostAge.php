<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PostAge extends Model
{
    protected $table = 'post_age';
    protected $primaryKey = 'idpost_age';
}

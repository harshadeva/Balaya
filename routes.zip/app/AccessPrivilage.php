<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AccessPrivilage extends Model
{
    protected $table = 'access_privilage';
    protected $primaryKey = 'idaccess_privilage';
}
